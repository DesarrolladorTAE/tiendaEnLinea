import{k as o,l as s}from"./index-C6z24cp-.js";const a=o(s.jsx("path",{d:"M19 9h-4V3H9v6H5l7 7zM5 18v2h14v-2z"}));export{a as F};
