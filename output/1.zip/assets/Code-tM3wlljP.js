import{k as o,l as s}from"./index-CWeldloM.js";const a=o(s.jsx("path",{d:"M9.4 16.6 4.8 12l4.6-4.6L8 6l-6 6 6 6zm5.2 0 4.6-4.6-4.6-4.6L16 6l6 6-6 6z"}));export{a as C};
